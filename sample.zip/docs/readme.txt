Vendor delivery sample.
